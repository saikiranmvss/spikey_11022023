-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 11, 2023 at 03:52 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `backup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `backup` ()  BEGIN
select user_pic,name,user_id from users where user_id=(select distinct(receiver_id) from users_messages where (receiver_id=id or sender_id=id) and receiver_id!=id);
SELECT msg_content from users_messages where (sender_id = (select distinct(receiver_id) from users_messages where (receiver_id=id or sender_id=id) and receiver_id!=id) and receiver_id= id) or (sender_id=id and receiver_id=(select distinct(receiver_id) from users_messages where (receiver_id=id or sender_id=id) and receiver_id!=id)) Order by msg_createddate desc limit 1;
END$$

DROP PROCEDURE IF EXISTS `getSingleUserChat`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getSingleUserChat` (IN `id` INT, IN `othermsgid` INT)  BEGIN
select * from users_messages where (receiver_id=othermsgid and sender_id=id) or (receiver_id=id and sender_id=othermsgid);
update users_messages set receiver_status=1 , sender_status = 1 where (receiver_id=id and sender_id=othermsgid);
select * from users where user_id=othermsgid;
select distinct(receiver_id) from users_messages where (receiver_id=id or sender_id=id) and receiver_id!=id;
END$$

DROP PROCEDURE IF EXISTS `getUsersData`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getUsersData` (IN `userId` INT, IN `otherUserId` INT)  BEGIN 
select users.user_pic,users.user_id,users.name , users_messages.msg_createddate, users_messages.receiver_status,users_messages.receiver_id,users_messages.msg_id,users_messages.msg_content from users_messages inner join users where ( ( users_messages.receiver_id=userId AND users_messages.sender_id=otherUserId ) OR ( users_messages.receiver_id=otherUserId AND users_messages.sender_id=userId ) ) and users.user_id=otherUserId order by users_messages.msg_createddate DESC limit 1;
END$$

DROP PROCEDURE IF EXISTS `get_usersdata`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_usersdata` (IN `id` INT)  BEGIN
select user_pic,name,user_id from users where user_id=(select distinct(receiver_id) from users_messages where (receiver_id=id or sender_id=id) and receiver_id!=id);
select receiver_id,msg_content from users_messages where (receiver_id=id or sender_id=id) and receiver_id!=id GROUP by receiver_id Order by msg_createddate DESC;
END$$

--
-- Functions
--
DROP FUNCTION IF EXISTS `getUsers_go`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `getUsers_go` (`emails` VARCHAR(255), `passed` VARCHAR(255)) RETURNS VARCHAR(255) CHARSET utf8mb4 BEGIN
   DECLARE val_pass varchar(255);
   DECLARE val varchar(255);
IF 
(select password from users where email = emails) !=''
THEN
SET val_pass= (select password from users where email = emails);
IF
val_pass!=passed
THEN
SET val='pass_err';
ELSE
SET val= (select user_id from users where email = emails);
end IF;
ELSE
SET val='email_err';
END IF;
RETURN val;
 END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` tinyint(4) NOT NULL,
  `user_status` tinyint(4) NOT NULL,
  `user_pic` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `friends` longtext DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `phone`, `password`, `user_type`, `user_status`, `user_pic`, `address`, `friends`) VALUES
(1, 'test', 'test@gmail.com', '056456456', 'tests', 1, 1, 'default.png', 'test', '[\"3\",\"2\",\"4\"]'),
(2, 'test2', 'test2@gmail.com', '056456456', 'test', 1, 1, 'man.jpg', 'test', '[\"4\",\"3\",\"1\",\"5\"]'),
(3, 'test3', 'test3@gmail.com', '056456456', 'test', 1, 1, 'man.jpg', 'sdfs', NULL),
(4, 'test4', 'test4@gmail.com', '05456456', 'test', 1, 1, 'man.jpg', 'test4', NULL),
(5, 'Ramam', 'Ramam@gmail.com', '05456456', 'test', 1, 1, 'default.png', 'tetsing', '[\"1\",\"2\"]');

-- --------------------------------------------------------

--
-- Table structure for table `users_messages`
--

DROP TABLE IF EXISTS `users_messages`;
CREATE TABLE IF NOT EXISTS `users_messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_content` longtext NOT NULL,
  `msg_status` tinyint(1) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `receiver_status` tinyint(1) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `msg_createddate` timestamp NOT NULL DEFAULT current_timestamp(),
  `sender_status` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_messages`
--

INSERT INTO `users_messages` (`msg_id`, `msg_content`, `msg_status`, `receiver_id`, `receiver_status`, `sender_id`, `msg_createddate`, `sender_status`, `user_id`) VALUES
(1, 'testing', 0, 1, 1, 2, '2023-02-04 19:30:00', 1, 1),
(2, 'test', 0, 1, 1, 2, '2023-02-04 20:30:00', 1, 1),
(3, 'testing', 0, 2, 1, 1, '2023-02-04 21:30:00', 1, 1),
(4, 'testing', 0, 2, 1, 1, '2023-02-04 21:50:00', 1, 1),
(5, 'dd', 0, 2, 1, 3, '2023-02-04 22:30:00', 1, 1),
(6, 'dd', 0, 3, 1, 2, '2023-02-04 23:30:00', 1, 1),
(7, 'hghghg', 1, 2, 1, 4, '2023-02-09 01:30:00', 1, 4),
(8, 'now', 0, 5, 1, 2, '2023-02-08 11:55:33', 1, 5),
(9, 'This is a testing message', 0, 2, 1, 4, '2023-02-09 03:43:44', 1, 4),
(10, 'Testing', 1, 2, 1, 5, '2023-02-09 04:37:23', 1, 5),
(11, 'test1', 1, 2, 1, 4, '2023-02-09 04:44:17', 1, 4),
(12, 'test2', 1, 4, 1, 2, '2023-02-09 06:34:19', 1, 2),
(13, 'tt', 1, 1, 1, 2, '2023-02-10 09:00:43', 1, 2),
(14, 'test', 1, 1, 1, 2, '2023-02-10 09:07:35', 1, 2),
(15, 'test1', 1, 1, 1, 2, '2023-02-10 09:08:02', 1, 2),
(16, 'test2', 1, 1, 1, 2, '2023-02-10 09:08:05', 1, 2),
(17, 'where', 1, 1, 1, 2, '2023-02-10 09:17:46', 1, 2),
(18, 'test', 1, 1, 1, 2, '2023-02-10 09:24:56', 1, 2),
(19, 'tsetset', 1, 1, 1, 2, '2023-02-10 09:26:24', 1, 2),
(20, 'testste', 1, 2, 1, 1, '2023-02-10 09:29:41', 1, 1),
(21, 'testste', 1, 2, 1, 1, '2023-02-10 09:32:19', 1, 1),
(22, 'sdsd', 1, 2, 1, 1, '2023-02-10 09:32:29', 1, 1),
(23, 'test', 1, 1, 1, 2, '2023-02-10 09:32:38', 1, 2),
(24, 'testsdd', 1, 2, 1, 1, '2023-02-10 09:34:57', 1, 1),
(25, 'kick', 1, 1, 1, 2, '2023-02-10 09:36:28', 1, 2),
(26, 'tset', 1, 1, 1, 2, '2023-02-10 09:36:54', 1, 2),
(27, 'tt', 1, 1, 1, 2, '2023-02-10 09:40:10', 1, 2),
(28, 'ds', 1, 1, 1, 2, '2023-02-10 09:46:28', 1, 2),
(29, 'test', 1, 1, 1, 2, '2023-02-10 09:47:14', 1, 2),
(30, 'gg', 1, 2, 1, 1, '2023-02-10 09:48:21', 1, 1),
(31, 'fgff', 1, 2, 1, 1, '2023-02-10 10:12:05', 1, 1),
(32, 'test', 1, 2, 1, 1, '2023-02-10 10:13:13', 1, 1),
(33, 'gg', 1, 2, 1, 1, '2023-02-10 10:17:35', 1, 1),
(34, 'sss', 1, 2, 1, 1, '2023-02-10 10:51:11', 1, 1),
(35, 'test', 1, 2, 1, 1, '2023-02-10 10:51:56', 1, 1),
(36, 'test', 1, 2, 1, 1, '2023-02-10 11:03:59', 1, 1),
(37, 'ddddd', 1, 2, 1, 1, '2023-02-10 11:04:05', 1, 1),
(38, 'test', 1, 2, 1, 1, '2023-02-10 11:04:11', 1, 1),
(39, 'checked', 1, 1, 1, 2, '2023-02-10 11:13:52', 1, 2),
(40, 'test', 1, 2, 1, 1, '2023-02-10 11:15:19', 1, 1),
(41, 'dd', 1, 1, 1, 2, '2023-02-10 11:29:16', 1, 2),
(42, 'dsdsds', 1, 2, 1, 1, '2023-02-10 11:30:28', 1, 1),
(43, 'i know', 1, 1, 1, 2, '2023-02-10 12:00:46', 1, 2),
(44, 'esttt', 1, 1, 1, 2, '2023-02-10 12:03:16', 1, 2),
(45, 'checked it', 1, 1, 1, 2, '2023-02-10 12:03:22', 1, 2),
(46, 'what checked', 1, 2, 1, 1, '2023-02-10 12:03:28', 1, 1),
(47, 'i know man', 1, 1, 1, 2, '2023-02-10 12:03:33', 1, 2),
(48, 'tsetset', 1, 1, 1, 2, '2023-02-10 12:03:41', 1, 2),
(49, 'got it right', 1, 2, 1, 1, '2023-02-11 03:23:57', 1, 1),
(50, 'test', 1, 2, 1, 1, '2023-02-11 03:28:05', 1, 1),
(51, '\nwhat are you doing', 1, 2, 1, 1, '2023-02-11 03:28:10', 1, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
